from Utils import TransformationEnum, Blob, BlobPairInfo, TransformationFrame
from PIL import Image, ImageChops, ImageDraw
from collections import deque, defaultdict

class TxFinder:
    def __init__(self):
        self.PIXEL_PRESENT = 1
        self.PIXEL_NOT_PRESENT = 0
        self.IMAGE_WIDTH = 0
        self.IMAGE_HEIGHT = 0
        self.ThresholdScore = 92

    def find_tx(self, A, B, C):
        self.IMAGE_WIDTH = A.width
        self.IMAGE_HEIGHT = A.height
        self.BlobsA = self.get_blobs(A)
        #self.show_blobs(A,BlobsA)
        self.BlobsB = self.get_blobs(B)
        self.BlobsC = self.get_blobs(C)
        Tx = []

        #Super Transformations (level 1)
        Tx0 = self.find_super_tx(A, B, C)
        Tx.append(Tx0)

        #Figure Transformations (level 2)
        Tx1 = self.find_figure_tx(A, B)
        Tx2 = self.find_figure_tx(B, C)
        Tx.append([Tx1,Tx2])

        #Blob Transformations (level 3)
        if max(Tx0.getHighestScore(),Tx1.getHighestScore(),Tx2.getHighestScore()) < self.ThresholdScore:
            Tx3 = self.find_blob_tx(A, self.BlobsA, B, self.BlobsB)
            Tx4 = self.find_blob_tx(B, self.BlobsB, C, self.BlobsC)
            Tx5 = self.find_blob_tx(A, self.BlobsA, C, self.BlobsC)
            #                   0                           4                   6                   7
            #details contains (same,morph,translate,scale,addition,deletion,blobCountDiffernce,morph pattern)
            if len(Tx3.getBestTxDetails())>0 and len(Tx4.getBestTxDetails())>0:
                if Tx3.getBestTxDetails()[6] != Tx4.getBestTxDetails()[6]:
                    Tx4.setBestTxDetails(Tx4.getBestTxDetails()[0:6]+(99,))#99denote no common increasing or decreasing blob count difference
            if len(Tx5.getBestTxDetails())>0 and Tx5.getBestTxDetails()[1] >=1:
                Tx3.setBestTxDetails(Tx3.getBestTxDetails()+(1,)) #Adding morph pattern bit
                Tx4.setBestTxDetails(Tx4.getBestTxDetails()+(1,))
            else:
                Tx3.setBestTxDetails(Tx3.getBestTxDetails()+(0,)) #Adding morph pattern bit
                Tx4.setBestTxDetails(Tx4.getBestTxDetails()+(0,))
            Tx.append([Tx3,Tx4])
        return Tx

    def find_diag_tx(self, A, B):
        self.IMAGE_WIDTH = A.width
        self.IMAGE_HEIGHT = A.height
        Tx = []
        self.BlobsA = self.get_blobs(A)
        self.BlobsB = self.get_blobs(B)

        #Figure Transformations (level 2)
        Tx1 = self.find_figure_tx(A, B)
        Tx.append(Tx1)

        #Blob Transformations (level 3)
        if Tx1.getHighestScore() < self.ThresholdScore:
            Tx3 = self.find_blob_tx(A, self.BlobsA, B, self.BlobsB)
            #details contains (same,morph,translate,scale,addition,deletion,morph pattern)
            if len(Tx3.getBestTxDetails())>0 and Tx3.getBestTxDetails()[1] >=1:
                Tx3.setBestTxDetails(Tx3.getBestTxDetails()+(1,)) #Adding morph pattern bit
            else:
                Tx3.setBestTxDetails(Tx3.getBestTxDetails()+(0,)) #Adding morph pattern bit
            Tx.append(Tx3)
        return Tx

    def find_super_tx(self, A, B, C):
        Tx = TransformationFrame()
        Tx.assignTxScore(TransformationEnum.ConstantAddition, self.constant_addition(A, B, C))
        Tx.assignTxScore(TransformationEnum.ConstantSubtraction, self.constant_subtraction(A, B, C))
        Tx.assignTxScore(TransformationEnum.Addition, self.addition(A, B, C))
        Tx.assignTxScore(TransformationEnum.Subtraction, self.subtraction(A, B, C))
        Tx.assignTxScore(TransformationEnum.AddcumSub, self.addcum_sub(A, B, C))
        Tx.assignTxScore(TransformationEnum.Common, self.common(A, B, C))
        Tx.assignTxScore(TransformationEnum.Divergence, self.divergence(A, B, C))
        Tx.assignTxScore(TransformationEnum.Convergence, self.convergence(A, B, C))
        correspAC, additionCnt, deletionCnt = self.get_blob_correspondence(self.BlobsA, self.BlobsC)
        ACMetaData = self.get_blob_meta_data(correspAC, self.BlobsA, self.BlobsC)
        if ACMetaData['repetition'] == False and ACMetaData['oneToOne'] == True:
            Tx.assignTxScore(TransformationEnum.Migration, self.migration(A, B, C))
        return Tx

    def find_figure_tx(self, A, B):
        Tx = TransformationFrame()
        #Transformations (level 2)
        Tx.assignTxScore(TransformationEnum.Same, (self.same(A, B), 0))
        if Tx.getHighestScore() < self.ThresholdScore:
            Tx.assignTxScore(TransformationEnum.Expansion, self.repetition_by_expansion(A, B))
            Tx.assignTxScore(TransformationEnum.Translation, self.repetition_by_translation(A, B))
        return Tx

    def find_blob_tx(self, A, BlobsA, B, BlobsB):
        Tx = TransformationFrame()
        Tx.Blobs.append(BlobsA)
        Tx.Blobs.append(BlobsB)
        Tx.corresp, additionsToBlobsB, deletionsInBlobsA = self.get_blob_correspondence(BlobsA, BlobsB)
        Tx.BlobMetaData = self.get_blob_meta_data(Tx.corresp, BlobsA, BlobsB)
        numberMorphed = 0
        Tx.BlobMetaData['AdditionCount'] = additionsToBlobsB
        Tx.BlobMetaData['DeletionCount'] = deletionsInBlobsA
        #Blob Transformations ( level 3)
        if Tx.BlobMetaData['repetition'] == False:
            #only if more than one obj is present in figure
            if len(Tx.corresp.keys()) >= 1:
                details = self.blob_transforms(Tx.corresp, Tx.Blobs[0], Tx.Blobs[1])
                details = (details[0],details[1],details[2]+numberMorphed,details[3],details[4])
                details = details + (Tx.BlobMetaData['AdditionCount'],Tx.BlobMetaData['DeletionCount'],Tx.BlobMetaData['blobCountDifference'])
                Tx.assignTxScore(TransformationEnum.BlobTransforms, details)
                Tx.assignTxScore(TransformationEnum.ScalingOfOneObject, self.scaling_of_one_object(Tx.corresp, Tx.Blobs[0], Tx.Blobs[1]))
                Tx.assignTxScore(TransformationEnum.TranslationOfOneObject, self.translation_of_one_object(Tx.corresp, Tx.Blobs[0], Tx.Blobs[1]))
        return Tx

    def blob_transforms(self, corresp, BlobsA, BlobsB):
        morphCount = 0
        translationCount = 0
        scalingCount = 0
        sameCount = 0
        for aid,bIdAndVals in corresp.items():
            pairInfo = bIdAndVals[0][2]
            if pairInfo.isMorph():
                morphCount += 1
            if pairInfo.isTranslated():
                translationCount += 1
            if pairInfo.isScaled():
                scalingCount += 1
            if pairInfo.isSame():
                sameCount += 1
        score = 99
        return score, sameCount, morphCount, translationCount, scalingCount

    def addition(self, A, B, C):
        AplusB = ImageChops.lighter(A,B)
        score = self.same(AplusB, C)
        return score, 0

    def subtraction(self, A, B, C):
        AuB = ImageChops.lighter(A,B)
        Diff = ImageChops.difference(AuB,B)
        score = self.same(Diff, C)
        return score, 0

    def addcum_sub(self, A, B, C):
        add = ImageChops.lighter(A,B)
        comm = ImageChops.darker(A,B)
        Diff = ImageChops.difference(add,comm)
        score = self.same(Diff, C)
        return score, 0

    def common(self, A, B, C):
        common = ImageChops.darker(A,B)
        score = self.same(common, C)
        return score, 0

    def migration(self, A, B, C):
        #Horizontal migration
        #A super transformation where blobs in A from their end migrate to pos in C in the other end via B
        if self.IMAGE_WIDTH == 0 or self.IMAGE_HEIGHT == 0:
            self.IMAGE_WIDTH = A.width
            self.IMAGE_HEIGHT = A.height
        migDir = []
        migCol = []
        ABscore = 0
        BCscore = 0
        croppedBlobs = []
        migImage = Image.new("1",(self.IMAGE_WIDTH,self.IMAGE_HEIGHT))
        if len(self.BlobsA) >0:
            for b in self.BlobsA[:]:
                if b.startCol<self.IMAGE_WIDTH/2:
                    migDir.append(1)
                else:
                    migDir.append(-1)
                migCol.append(b.startCol)
                cropped = A.crop((b.startCol,b.startRow,b.endCol,b.endRow))
                croppedBlobs.append(cropped)
            for i in range(1,int(self.IMAGE_WIDTH  - migCol[0])+1):
                migImage = Image.new("1",(self.IMAGE_WIDTH,self.IMAGE_HEIGHT))
                for b in self.BlobsA:
                    newImage = Image.new("1",(self.IMAGE_WIDTH,self.IMAGE_HEIGHT))
                    migCol[b.id] = migCol[b.id]+migDir[b.id]
                    newImage.paste(croppedBlobs[b.id],(migCol[b.id],b.startRow))
                    migImage = ImageChops.lighter(migImage,newImage)
                score = self.similarity(migImage, B)
                if score >= 98:
                    ABscore = score
                    break
            #migImage.save(str(time.time())+"_AB.png","PNG")
            if ABscore >= 98:
                for i in range(1,int(self.IMAGE_WIDTH - migCol[0])+1):
                    migImage = Image.new("1",(self.IMAGE_WIDTH,self.IMAGE_HEIGHT))
                    for b in self.BlobsA:
                        newImage = Image.new("1",(self.IMAGE_WIDTH,self.IMAGE_HEIGHT))
                        migCol[b.id] = migCol[b.id]+migDir[b.id]
                        newImage.paste(croppedBlobs[b.id],(migCol[b.id],b.startRow))
                        migImage = ImageChops.lighter(migImage,newImage)
                    score = self.similarity(migImage, C)
                    if score >= 96:
                        BCscore = score
                        break
            if ABscore >= 98 and BCscore >= 96:
                return (ABscore+BCscore)/2, ABscore, BCscore
            else:
                #vertical migration
                migDir = []
                #migCol is migRow here
                migCol = []
                ABscore = 0
                BCscore = 0
                croppedBlobs = []
                migImage = Image.new("1",(self.IMAGE_WIDTH,self.IMAGE_HEIGHT))
                for b in self.BlobsA[:]:
                    if b.startRow<self.IMAGE_HEIGHT/2:
                        migDir.append(1)
                    else:
                        migDir.append(-1)
                    migCol.append(b.startRow)
                    cropped = A.crop((b.startCol,b.startRow,b.endCol,b.endRow))
                    croppedBlobs.append(cropped)
                for i in range(1,int(self.IMAGE_HEIGHT - migCol[0])+1):
                    migImage = Image.new("1",(self.IMAGE_WIDTH,self.IMAGE_HEIGHT))
                    for b in self.BlobsA:
                        newImage = Image.new("1",(self.IMAGE_WIDTH,self.IMAGE_HEIGHT))
                        migCol[b.id] = migCol[b.id]+migDir[b.id]
                        newImage.paste(croppedBlobs[b.id],(b.startCol,migCol[b.id]))
                        migImage = ImageChops.lighter(migImage,newImage)
                    score = self.similarity(migImage, B)
                    if score >= 98:
                        ABscore = score
                        break
                #migImage.save(str(time.time())+"_AB.png","PNG")
                if ABscore >= 98:
                    for i in range(1,int(self.IMAGE_HEIGHT - migCol[0])+1):
                        migImage = Image.new("1",(self.IMAGE_WIDTH,self.IMAGE_HEIGHT))
                        for b in self.BlobsA:
                            newImage = Image.new("1",(self.IMAGE_WIDTH,self.IMAGE_HEIGHT))
                            migCol[b.id] = migCol[b.id]+migDir[b.id]
                            newImage.paste(croppedBlobs[b.id],(b.startCol,migCol[b.id]))
                            migImage = ImageChops.lighter(migImage,newImage)
                        score = self.similarity(migImage, C)
                        if score >= 96:
                            BCscore = score
                            break
        return (ABscore+BCscore)/2, ABscore, BCscore

    def divergence(self, A, B, C):
        #A super transformation where object in A splits into two
        ABscore, ABloc, ABlor, ABroc, ABror = self.repetition_by_translation(A, B)
        ACscore, ACloc, AClor, ACroc, ACror = self.repetition_by_translation(A, C)
        if abs(ABscore-ACscore)<3:
            return (ABscore+ACscore)/2, ABscore, ACscore
        return 0,0,0

    def convergence(self, A, B, C):
        #A super transformation where objects in A merge into one
        return self.divergence(C, B, A)

    def constant_addition(self, A, B, C):
        if self.similarity(ImageChops.lighter(A, B), B)>99:
            AminusB = ImageChops.difference(A,B)
            ABAdditionArea = self.get_fill_percentage(AminusB, 0, 0, AminusB.width, AminusB.height)
            if self.similarity(ImageChops.lighter(B, C), C)>99:
                BminusC = ImageChops.difference(B,C)
                BCAdditionArea = self.get_fill_percentage(BminusC, 0, 0, BminusC.width, BminusC.height)
                score = 0
                if ABAdditionArea > 1 and BCAdditionArea > 1:
                    if abs(ABAdditionArea - BCAdditionArea) < 4:
                        similarity = self.similarity(C, ImageChops.lighter(B, ImageChops.difference(B, C)))
                        score = similarity
                return  score, ABAdditionArea, BCAdditionArea
        return 0, 0, 0

    def constant_subtraction(self, A, B, C):
        score, BCSubArea, ABSubArea = self.constant_addition(C, B, A)
        return score, ABSubArea, BCSubArea

    def scaling_of_one_object(self, corresp, BlobsA, BlobsB):
        widthScaling = 0
        heightScaling = 0
        score = 0
        for k,v in corresp.items():
            #if all parameters are different 1 possibility is scaling
            if v[0][1] >= 3:
                if BlobsA[k].width!=BlobsB[v[0][0]] or BlobsA[k].height!=BlobsB[v[0][0]]:
                    widthScaling = BlobsB[v[0][0]].width/BlobsA[k].width
                    heightScaling = BlobsB[v[0][0]].height/BlobsA[k].height
                    score = 99
        return score, widthScaling, heightScaling

    def translation_of_one_object(self, corresp, BlobsA, BlobsB):
        data = []
        score = 0
        for k, v in corresp.items():
            colOffset, rowOffset = self.get_blob_offset(BlobsA[k], BlobsB[v[0][0]])
            if colOffset<-1 or colOffset>1 or rowOffset<-1 or rowOffset>1:
                data.append((k, v[0][0],colOffset,rowOffset))
        if len(data)>0:
            score = 99
        return score,data

    def get_blob_offset(self, a, b):
        colOffset = b.startCol - a.startCol
        rowOffset = b.startRow - a.startRow
        return colOffset, rowOffset

    def get_blob_meta_data(self, correspondences, ba, bb):
        repetition = False
        oneToOne = True
        fillPercentage = []
        for key,val in correspondences.items():
            if len(val)>1:
                repetition = True
                oneToOne = False
            else:
                fillPercentage.append((key,val,abs(ba[key].fill-bb[val[0][0]].fill)))
            if len(val) == 0:
                oneToOne = False
        if len(correspondences) < len(ba):
            oneToOne = False
        blobCountDifference = len(bb)-len(ba)
        metaData= {'repetition':repetition,'fillComparison':fillPercentage,'oneToOne':oneToOne,'blobCountDifference':blobCountDifference}
        return metaData

    def get_blob_correspondence(self, BlobsA, BlobsB):
        MAX_DIFF = 6
        ba = BlobsA
        bb = BlobsB
        remainingABlobs = len(ba)
        remainingBBlobs = len(bb)
        notAssignedBBlobs = 0
        notAssignedABlobs = 0
        corresp = defaultdict(list)
        for b in bb[:]:
            assigned = False
            minDiff = 99
            corBlobId = 0
            blobPairInfo = BlobPairInfo()
            for a in ba[:]:
                s, info = self.get_blob_similarity_score_and_info(b, a)
                if s <= minDiff:
                    if s<MAX_DIFF or info.iCenter:
                        minDiff = s
                        corBlobId = a.id
                        blobPairInfo = info
                        assigned = True
            if assigned:
                corresp[corBlobId].append((b.id,minDiff,blobPairInfo))
            else:
                notAssignedBBlobs += 1
        if len(corresp) < len(ba):
            notAssignedABlobs = len(ba) - len(corresp)
        AdditionCount = notAssignedBBlobs
        DeletionCount = notAssignedABlobs
        return corresp, AdditionCount, DeletionCount

    def get_blob_similarity_score_and_info(self, b, a):
        score = 0
        info = BlobPairInfo()
        if self.is_in_range(b.startCol, a.startCol, 1):
            info.iStartCol = True
        else:
            score += 1
        if self.is_in_range(b.startRow, a.startRow, 1):
            info.iStartRow = True
        else:
            score += 1
        if self.is_in_range(b.width, a.width, 1):
            info.iWidth = True
        else:
            score += 1
        if self.is_in_range(b.height, a.height, 1):
            info.iHeight = True
        else:
            score += 1
        if self.is_in_range(b.fill, a.fill, 0.011):#0.004
            info.iFill = True
        else:
            score += 1
        if self.is_in_range(b.filledPixels, a.filledPixels, 42):#change can be .5 percentage #42#34#22
            info.iFilledPixels = True
        else:
            score += 1
        if self.is_in_range(b.startCol + b.width / 2, a.startCol + a.width / 2, 5):
            if self.is_in_range(b.startRow + b.height / 2, a.startRow + a.height / 2, 5):
                info.iCenter = True
        return score, info

    def is_in_range(self, p, q, range):
        if p <= q+range and p >= q-range:
            return True
        else:
            return False

    def show_blobs(self, A, BlobsA):
        ad = ImageDraw.Draw(A,"1")
        for ba in BlobsA[:]:
            ad.rectangle([ba.startCol,ba.startRow,ba.endCol,ba.endRow], None, "blue")
        del ad
        A.show()

    def get_blobs(self, A):
        imgCopy = A.copy()  # type: object
        img1 = imgCopy.getdata()
        img = list(imgCopy.getdata())
        #delete weak links in image
        #end points or exceptioncal case handling - border case do
        for i in range(len(img)):
            if img[i]!= 0:
                if img[i-1] == 0 and img[i+1] == 0:
                    img[i] = 0
                if img[i - A.width] == 0 and img[i + A.width]==0:
                    img[i]=0
        img1.putdata(img)
        Blobs = []
        id = 0
        bbox = img1.getbbox()
        while bbox!=None :
            r = bbox[1]
            c = bbox[0]
            while c <= bbox[2]:
                if img[c + r*A.width] != 0:
                    break
                c = c+1
            img[c + r*A.width] = 0
            b = Blob()
            b.id = id
            sr, sc, er, ec, img, filledPixels = self.fillBlob(img, A. width, c, r)
            b.startRow = sr
            b.startCol = sc
            b.endRow = er
            b.endCol = ec
            b.width = b.endCol - b.startCol + 1
            b.height = b.endRow - b.startRow + 1
            b.filledPixels = filledPixels
            b.fill = filledPixels/(b.width*b.height)
            Blobs.append(b)
            id = id + 1
            img1.putdata(img)
            bbox = img1.getbbox()
        return Blobs

    def get_fill_percentage(self, img, sc, sr, ec, er):
        pixels = img.crop((sc,sr,ec,er)).getdata()
        whitePixelCount = 0
        for pixel in pixels:
            if pixel != self.PIXEL_NOT_PRESENT:
                whitePixelCount += 1
        totalPixels = len(pixels)
        score = 100*(whitePixelCount/float(totalPixels))
        return score

    def fillBlob(self, img, width, c, r):
        sr = r
        sc = c
        er = r
        ec = c
        filledPixels = 0
        queue = deque()
        queue.append((c, r))
        while queue:
            c,r = queue.popleft()
            for i in range(-1, 2):
                for j in range(-1, 2):
                    if img[c+j + (r+i)*width] != 0:
                        img[c+j + (r+i)*width] = 0
                        filledPixels += 1
                        queue.append((c+j,r+i))
                        if r+i > er:
                            er = r+i
                        if c+j > ec:
                            ec = c+j
                        if r+i < sr:
                            sr = r+i
                        if c+j < sc:
                            sc = c+j
        return sr, sc, er, ec, img, filledPixels

    def repetition_by_translation(self, A, B):
        s = A.getbbox()
        f = B.getbbox()
        if f != None and s != None:
            left_offset_col = f[0] - s[0]
            sLRow = self.get_first_active_row_in_col(A, s[1], s[3], s[0])
            fLRow = self.get_first_active_row_in_col(B, f[1], f[3], f[0])
            left_offset_row = fLRow - sLRow
            if abs(left_offset_col) > 5 or abs(left_offset_row) > 5:
                A1 = ImageChops.offset(A, left_offset_col, left_offset_row)
                right_offset_col = f[2] - s[2]
                sRRow = self.get_last_active_row_in_col(A, s[1], s[3], s[2] - 1)
                fRRow = self.get_last_active_row_in_col(B, f[1], f[3], f[2] - 1)
                right_offset_row = fRRow - sRRow
                A2 = ImageChops.offset(A,right_offset_col,right_offset_row)
                ADash = ImageChops.lighter(A1, A2)
                score = self.similarity(ADash, B)
                details = score, left_offset_col, left_offset_row, right_offset_col, right_offset_row
                return details
            else:
                details = 0,0,0,0,0
                return details
        else:
            details = 0,0,0,0,0
            return details

    def get_first_active_row_in_col(self, image, startRow, endRow, col):
        img = list(image.getdata())
        aRow = startRow
        for i in range(startRow,endRow+1):
            if img[col+i*image.width] != 0:
                aRow = i
                break
        return aRow

    def get_last_active_row_in_col(self, image, startRow, endRow, col):
        img = list(image.getdata())
        aRow = endRow
        for i in reversed(range(startRow,endRow+1)):
            if img[col+i*image.width] != 0:
                aRow = i
                break
        return aRow

    def repetition_by_expansion(self, A, B):
        compA = A.getbbox()
        compB = B.getbbox()
        score = 0
        xGrowth = 0
        yGrowth = 0
        if compA!= None and compB!= None:
            if compB[0]<compA[0] and compB[2]>compA[2]:
                xGrowth = (compA[0] - compB[0] + compB[2] - compA[2])/2;
                if compB[1]<compA[1] and compB[3]>compA[3]:
                    yGrowth = (compA[1] - compB[1] + compB[3] - compA[3])/2
                    score = 97 #expansion
        details = score, xGrowth, yGrowth
        return details

    def same(self, A, B):
        #returns the percentage of similarity
        highestScore = 0
        for i in range(-6,7,2):
            for j in range(-6,7,2):
                B1 = ImageChops.offset(B,i,j)
                s = self.similarity(A, B1)
                if s>highestScore:
                    highestScore = s
        return highestScore

    def similarity(self, A, B):
        diff = ImageChops.difference(A,B)
        pixels = diff.getdata()
        whitePixelCount = 0
        for pixel in pixels:
            if pixel != self.PIXEL_NOT_PRESENT:
                whitePixelCount += 1
        totalPixels = len(pixels)
        score = 100 - 100*(whitePixelCount/float(totalPixels))
        return score
